from Screens.Screen import Screen

class SubtitleDisplay(Screen):
	pass

	# not really much to do...
