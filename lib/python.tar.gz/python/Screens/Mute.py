from Screens.Screen import Screen

class Mute(Screen):
	pass

