# some helper classes first:
class HTMLComponent:
	def __init__(self):
		pass

	def produceHTML(self):
		return ""

